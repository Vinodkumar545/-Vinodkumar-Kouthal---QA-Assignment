Vinodkumar Kouthal - QA Assignment

Tool/Software Version Used:
Selenium 2.50.0
Java 1.7
IE 11.726.15063.0
Chrome 62.0.3202.94
Mozilla 30
apache POI 3.15

You may notice Selenium and Mozilla have lower version, that is becuase the current person computer setting for Selenium works just fine!

Breif on the automation framework: I have quickly implemented POM framework, data driver framework and TestNG framework (can run testNG programmatically!).
As the assignment was based on the browsed based, you need to refer to 'testBase.TestBase' class and method called 'selectBrowser' which accepts the argument 
of String value of Browser name to initiate the browser that matches i.e., InternetExplorer, FirefoxDriver, ChromeDriver

How to run the scripts?
	1. Pre configure the value in the 'utilies.Constant' class i.e., Browser, url, testData path/location
	2. Provide the necessary details in the test data sheet - Note the row number you want to execute
	3. Move the 'testCase.MasterExecutor' class and fill in below details as argument (in order please)
		a. "testCases.BrowserBasedTesting", "ITestCaseNumber", "1"
		b. Here, first string the class name and 1 is the rowNumber.
		c. Run the this Programmatically TestNG code and output would be displayed as expected with execution

