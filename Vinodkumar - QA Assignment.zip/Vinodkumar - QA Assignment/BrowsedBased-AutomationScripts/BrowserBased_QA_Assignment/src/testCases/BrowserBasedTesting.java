package testCases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import testBase.TestBase;
import utilies.Constant;
import utilies.ExcelReader;
import pOM_galary.*;

public class BrowserBasedTesting extends TestBase {
	@BeforeMethod
	public void beforeStart() {
		initialize();
	}
	
	@Parameters({ "ITestCaseNumber"})
	@Test
	public void testExecution(String ITestCaseNumber) throws Exception {
		RegisterForm rF = new RegisterForm(driver);
//		System.out.println(ITestCaseNumber);
		ExcelReader.setExcelFile(Constant.path_testData, Constant.sheetname_testData);
		rF.submitTheForm(ITestCaseNumber);
	}
	
	@AfterMethod
	public void endTest() {
		closeBrowser();
	}
}