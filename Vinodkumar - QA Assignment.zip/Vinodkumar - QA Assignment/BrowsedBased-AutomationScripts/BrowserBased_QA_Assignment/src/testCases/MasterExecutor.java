package testCases;

import java.util.*;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

public class MasterExecutor {
	
	/*
	 * 
	 * @param className - Argument should be 'packageName.testcasename' e.g. "testCases.BrowserBasedTesting"
	 * @param iTestCaseNumber - This argument acts a key for iTestCaseRow, so just keep the same name
	 * @param iTestCaseRow - This row is row in the test data excel (as column are pre-configures) that needs to executed. This is 
	 * 		  hard code for now, but further enhancement it taken drived from excel sheet and even iterate the testNG class!
	 * 
	 * REASON for running TestNG Programmatically is that we can run the number of class and iterate test case during RUNTIME
	 * 
	 * But i'm still working on this framework along, hoping to complete at earliest 
	 */
	public void testNGSuite(String className, String iTestCaseNumber, String iTestCaseRow) {
		
		List<XmlSuite> suites = new ArrayList<XmlSuite>();
		List<XmlClass> classes = new ArrayList<XmlClass>();
		
		HashMap<String, String> mP = new HashMap<String, String>();
		mP.put(iTestCaseNumber, iTestCaseRow);
		
		XmlSuite suite = new XmlSuite();
		suite.setName("ProgramSuite");
		
		XmlTest test = new XmlTest(suite);
		test.setName("ProgramTest");
		test.setParameters(mP);
		
		XmlClass class1 = new XmlClass(className);
		classes.add(class1);
		
		test.setXmlClasses(classes);
		
		suites.add(suite);
		
		TestNG tng = new TestNG();
		tng.setXmlSuites(suites);
		tng.run();
	}
	
	public static void main(String args[]) {
		MasterExecutor m = new MasterExecutor();
		m.testNGSuite("testCases.BrowserBasedTesting", "ITestCaseNumber", "1");
	}
}