package testBase;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import utilies.*;

public class TestBase {
	public static WebDriver driver;
	
	public static void initialize() {
		selectBrowser(Constant.browser);
		getURL(Constant.app_URL);
	}
	
	public static void selectBrowser(String browser) {
		if(browser.equalsIgnoreCase("IE")) {
			driver = new InternetExplorerDriver();
		} else if(browser.equalsIgnoreCase("Mozilla")) {
//			System.setProperty("webdriver.gecko.driver", "location of the geckodriver.exe");
			driver = new FirefoxDriver();
		} else if(browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "V:\\Selenium\\Software\\IEDriverServer.exe");
			driver = new ChromeDriver();
		}
	}
	
	public static void getURL(String url) {
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	public static void closeBrowser() {
		driver.close();
	}
}