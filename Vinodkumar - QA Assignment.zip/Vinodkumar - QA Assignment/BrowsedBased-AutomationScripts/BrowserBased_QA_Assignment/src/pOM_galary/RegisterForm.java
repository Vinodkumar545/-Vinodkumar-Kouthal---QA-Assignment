package pOM_galary;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilies.Constant;
import utilies.ExcelReader;

public class RegisterForm {

@FindBy(xpath="//b[contains(text(), 'Registration Form')]")	
private static WebElement txt_RegistrationForm;
	
@FindBy(name="first_name")
private static WebElement txtBx_firstName;

@FindBy(name="last_name")
private static WebElement txtBx_lastName;

@FindBy(name="department")
private static WebElement dropDn_department;

@FindBy(name="user_name")
private static WebElement txtBx_userName;

@FindBy(name="user_password")
private static WebElement txtBx_pasword;

@FindBy(name="confirm_password")
private static WebElement txtBx_confirmPassword;

@FindBy(name="email")
private static WebElement txtBx_eMail;

@FindBy(name="contact_no")
private static WebElement txtBx_contactNo;

@FindBy(xpath=".//button[@class='btn btn-warning']")
private static WebElement btn_submitButton;

@FindBy(xpath="//b[contains(text(), 'Thanks')]")	
private static WebElement txt_Thanks;

public WebDriver driver;

	public RegisterForm(WebDriver driver) {
		this.driver = driver; 
		PageFactory.initElements(driver, this);
	}
	
	public void submitTheForm(String iTestCaseNumber) throws Exception {
		int iTestCaseRow = Integer.valueOf(iTestCaseNumber);
		
		String firstName = ExcelReader.getCellData(iTestCaseRow, Constant.col_firstname);
		String lastName = ExcelReader.getCellData(iTestCaseRow, Constant.col_lastname);
		String userName = ExcelReader.getCellData(iTestCaseRow, Constant.col_username);
		String password = ExcelReader.getCellData(iTestCaseRow, Constant.col_password);
		String confirmPassword = ExcelReader.getCellData(iTestCaseRow, Constant.col_confirmPasword);
		String eMail = ExcelReader.getCellData(iTestCaseRow, Constant.col_EMail);
		String contactNo = ExcelReader.getCellData(iTestCaseRow, Constant.col_contactNo);

		
		try {
			Assert.assertEquals("Registration Form", txt_RegistrationForm.getText());
			
			txtBx_firstName.sendKeys(firstName);
			txtBx_lastName.sendKeys(lastName);
			txtBx_userName.sendKeys(userName);
			txtBx_pasword.sendKeys(password);
			txtBx_confirmPassword.sendKeys(confirmPassword);
			txtBx_eMail.sendKeys(eMail);
			txtBx_contactNo.sendKeys(contactNo);
			btn_submitButton.click();
			
			Assert.assertEquals("Thanks", txt_Thanks.getText());
		} catch (Exception e) {
			System.out.println("Exception: "+e.getMessage());
		}
	}
}