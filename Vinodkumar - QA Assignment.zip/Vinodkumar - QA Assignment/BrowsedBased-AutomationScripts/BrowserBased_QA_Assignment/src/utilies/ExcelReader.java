package utilies;

import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	private static XSSFWorkbook excelWBook;
	private static XSSFSheet excelSheet;
	private static XSSFCell Cell;
	
	/*
	 * To set or activate the Excel File to start using it during run-time/execution
	 *  
	 * @param path
	 * @param sheetName
	 * @throws Exception
	 */
	public static void setExcelFile(String path, String sheetName) throws Exception {
		FileInputStream fis = new FileInputStream(path);
		
		excelWBook = new XSSFWorkbook(fis);
		excelSheet = excelWBook.getSheet(sheetName);
	}
	
	/*
	 * To read the cell value from the excel sheet and return the same
	 * 
	 * @param RowNum
	 * @param ColNum
	 * @throws Exception
	 * @return CellData
	 */
	public static String getCellData(int RowNum, int ColNum) throws Exception {
		try {
	    	Cell = excelSheet.getRow(RowNum).getCell(ColNum);
	        String CellData = Cell.getStringCellValue();
	        return CellData;
	    } catch (Exception e) {
	    	System.out.println("exception: "+e.getMessage());
	        return"";
	    }
	}
}