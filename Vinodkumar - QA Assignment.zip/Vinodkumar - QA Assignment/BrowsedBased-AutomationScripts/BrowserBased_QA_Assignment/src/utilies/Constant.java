package utilies;

public class Constant {
	public static final String browser = "Mozilla";
	public static final String app_URL = "http://adjiva.com/qa-test/";
	public static final String path_testData = "V:\\Selenium\\Software\\Workspace\\BrowserBased_QA_Assignment\\TestDataX.xlsx";
	public static final String sheetname_testData = "TestDataS";
	
	public static int col_firstname = 0;
	public static int col_lastname = 1;
	public static int col_department = 2;
	public static int col_username = 3;
	public static int col_password = 4;
	public static int col_confirmPasword = 5;
	public static int col_EMail = 6;
	public static int col_contactNo = 7;
}