import requests

if __name__ == '__main__':
    values = {
        "text": "Stride API works very well.",
        "parse_html": False,
        "social_media": False
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Token demo_key'
    }

    test = requests.post("https://api.stride.ai/doc_sentiment.json", data=values, headers=headers)
    print(test.status_code)
    test.encoding = 'ISO-8859-1'
    print(test.content)
    print(test.json())
