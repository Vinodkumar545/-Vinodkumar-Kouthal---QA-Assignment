import requests


if __name__ == '__main__':
    values = '''
    {
        "text": "Stride API works very good.",
        "parse_html": false,
        "social_media": false
    } '''

    headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Token demo_key'
    }

    print(values)
    print(headers)

    # dict_b = {}
    post_url = 'https://api.stride.ai/doc_sentiment.json'

    test = requests.post(post_url, data=values, headers=headers)
    print(test.status_code)
    test.encoding = 'ISO-8859-1'
    # print(test.headers)
    # print(test.content)
    # dic_content = test.content
    # print(dic_content)

    print(test.json())
    test_json = test.json()
    # print(type(test_json))
    # print(len(test_json))
    # print(test_json.keys())
    # print(test_json.values())
    # print(test_json.items())

    print(test_json.get('sentiment'))
    print(test_json.get('score'))

    # b = dic_content.replace(b"sentiment", b"f")
    # b = dic_content.co
    # print(list(str(dic_content)))

    # arr = bytearray(str(dic_content), "ascii")
    # print(arr)
    # result = arr.decode("ascii")
    # print(result)
    # print(isinstance(result, str))
    # a = result.split("'", 3)
    # print(a[1])

    # print(type(dic_content))
    # bytearray(dic_content)
    # print(dic_content)
    # print(isinstance(dic_content, tuple))
    # dic_content.split()
    # print(dic_content)