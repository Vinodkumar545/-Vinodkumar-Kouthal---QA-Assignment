import requests


if __name__ == '__main__':
    values = '''
    {
        "text": "Freud's experimentation had its hazards, too. One associate, Ernst von Fleischl-Marxzow, had been dealing with a hand injury with large doses of morphine. Dr. Freud administrated cocaine as a solution for the man’s morphine addiction turned him into an addled, morphine-cocaine addict who died seven years later. He was the first person known to suffer the paranoia and delusions of bugs crawling under the skin that are common to heavy cocaine addicts.",
        "parse_html": false
    }'''

    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Token demo_key'
    }

    test = requests.post('https://api.stride.ai/sentence_wise_sentiment.json', data=values, headers=headers)
    print(test.status_code)
    test.encoding = 'ISO-8859-1'
    # test.encoding = 'uft-8'
    print(test.content)
    print(test.json())
    # print(test.reason)
    # print(test.text)
