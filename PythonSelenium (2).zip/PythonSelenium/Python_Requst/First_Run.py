import requests

# test = requests.get("http://www.hipstercode.com")
#
# print(test)
# # Output: <Response [200]>
#
# print(type(test))
# # Output: <class 'requests.models.Response'>
#
# print(test.__getstate__)
# # Output: <bound method Response.__getstate__ of <Response [200]>>
#
# output_file = open("C:\\Users\\Rajshekhar\\Desktop\\Learning Python Request\\test_text.txt", "w")
# test.encoding = 'ISO-8859-1'
# output_file.write(str(test.text))
# # Output: All captured in the text

my_list_of_Links = [
    # "http://www.hipstercode.com",
    # "http://www.hipstercode.com/about",
    # "http://www.google.com",
    "http://www.google.com/"
    ]

for index, link in enumerate(my_list_of_Links):
    payload = {'q': 'test'}
    test1 = requests.get(link, params=payload)
    print("Response for the link ", link, "is: ", test1)
    print("get State for the link ", link, "is: ", test1.__getstate__)
    # output_file1 = open("C:\\Users\\Rajshekhar\\Desktop\\Learning Python Request\\test"+str(index)+".txt", "w")
    test1.encoding = 'ISO-8859-1'
    # output_file1.write(str(test1.text))
    # print(test1.headers)
    # print(test1.cookies)
    # print(test1.cookies.get_dict())
    # print(test1.text)
    print(test1.url)
