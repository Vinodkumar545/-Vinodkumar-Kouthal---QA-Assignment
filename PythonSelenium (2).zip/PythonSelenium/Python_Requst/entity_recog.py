import requests


if __name__ == '__main__':
    values = '''
    {
        "text": "Vincent van Gogh was a Dutch post-Impressionist painter whose work had far-reaching influence on 20th-century art.",
        "parse_html": false
    }'''

    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Token demo_key'
    }

    test = requests.post('https://api.stride.ai/entities.json', data=values, headers=headers)
    print(test.status_code)
    test.encoding = 'ISO-8859-1'
    print(test.content)
    print(test.json())
