import requests


def retrieve_key_value(b):
    try:
        for b_id, b_value in b.items():
            # print("\nKey Value: ", b_id)
            # print("no of list: ", len(b[b_id]))
            length = len(b[b_id])
            for i in range(0, length):
                # print(b[b_id][i].items())
                for li_di, li_value in b[b_id][i].items():
                    # print("\nKey : ", li_di, "% Value: ", li_value)
                    # return keys.append(li_di), values.append(li_value)
                    print("The key is: ", li_di)
                    print("the value is: ",  li_value)
    except Exception as e:
        for key, value in b.items():
            print("\nKey: ", key, "& value: ", value)
            # return keys.append(li_di), values.append(li_value)
            print("The key is: ", li_di)
            print("the value is: ", li_value)


if __name__ == '__main__':
    values = '''
    {
        "text": "The food was great but the service was awful.",
        "parse_html": false,
        "social_media": false
    }'''

    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Token demo_key'
    }

    test = requests.post('https://api.stride.ai/subjective.json', data=values, headers=headers)
    print(test.status_code)
    test.encoding = 'ISO-8859-1'
    # print(test.content)
    # print(test.json())

    body = test.json()
    # print(type(body))
    # print(body.items())

    # body = {
    #     "sentiment": "VP",
    #     "score": 5.07
    #  }

    # print("senti body: ", b.items())

    print(retrieve_key_value(body))




    # print(body.keys())
    # print(body.get())/

    # b'{
    #     "sentiment_map":[
    #         {"category":"positive",
    #          "text":"food",
    #          "positive_score":9.6,
    #          "negative_score":0
    #          },
    #         {"category":"negative",
    #          "text":"service",
    #          "positive_score":0,
    #          "negative_score":-8.4
    #          }
    #     ]
    # }'
