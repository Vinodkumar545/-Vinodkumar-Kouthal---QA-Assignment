select_Browser = "chrome"
app_URL = "https://stride.docs.apiary.io/"

# folder Paths
chrome_exe_path = "C:\\Users\\Rajshekhar\\Desktop\\Python access\\chromedriver.exe"
ie_exe_path = "C:\\Users\\Rajshekhar\\Desktop\\Python access\\IEDriverServer.exe"
objec_resp_properies = "C:\\Users\\Rajshekhar\\PycharmProjects\\PythonSelenium\\ObjResp\\objectResp.properties"
excel_path = "C:\\Users\\Rajshekhar\\PycharmProjects\\PythonSelenium\\Practices\\test_data.xls"
excel_test_data = "test_data.xls"
excel_test_sheet_name = "Test_Scenario"
xcl_sheet_op = "Test_Output"
test_case_pass = "Pass"
test_case_fail = "FAIL"


# test_scenario column allocation or update
test_scenario_srno = 0
test_scenario_testID = 1
test_scenario_descriptio = 2
test_scenario_runmode = 3
test_scenario_result = 4

# test data column allocation
test_data_testID = 0
test_data_URL = 1
test_data_bodyKey = 2
test_data_bodyValue = 3
test_data_headerKey = 4
test_data_headerValue = 5
test_data_expResponse = 6
test_data_expBodyKey = 7
test_data_expBodyValue = 8
test_data_actResponse = 9
test_data_actBodyKey = 10
test_data_actBodyValue = 11
test_data_result = 12
