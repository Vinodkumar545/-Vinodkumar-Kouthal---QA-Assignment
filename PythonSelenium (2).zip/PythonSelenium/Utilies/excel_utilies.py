import xlrd, xlwt
from xlutils.copy import copy
from Utilies import Constant

work_book = xlrd.open_workbook(Constant.excel_test_data, "a")


# read_cell_data() - to read the cell value from the excel sheet
# by sending sheet name, row number, column number input as argument
def read_cell_data(excel_sheet_name, row_num, col_num):
    try:
        work_book_read = xlrd.open_workbook(Constant.excel_test_data)
        work_sheet = work_book_read.sheet_by_name(excel_sheet_name)
        cell_value = work_sheet.cell(row_num, col_num).value
        return cell_value
    except Exception as e:
        print("Class Excel_utilies | Method read_cell_data | Exception desc: ", e)


# write_cell_data() - to write into the cell in the excel sheet
# by sending sheet index, row number, column number, string input as argument
def write_cell_data(sheet_num, row_num, col_num, str_input):
    try:
        work_book_write = xlrd.open_workbook(Constant.excel_test_data)
        open_sheet = copy(work_book_write)
        open_sheet_in = open_sheet.get_sheet(sheet_num)
        open_sheet_in.write(row_num, col_num, str_input)
        save_work_book(open_sheet)
    except Exception as e:
        print("Class Excel_utilies | Method write_cell_data | Exception desc: ", e)


# get_number_of_test_cases() - To get a count of total number of test case that needs to executed
def get_no_of_iteration(test_sheet_name, test_col_id):
    try:
        wb_no_of_tc = xlrd.open_workbook(Constant.excel_test_data)
        work_sheet = wb_no_of_tc.sheet_by_name(test_sheet_name)
        test_case_list = work_sheet.col_values(test_col_id)
        no_of_it = test_case_list.__len__()
        return no_of_it
    except Exception as e:
        print("Class excel_utilies | Method get_number_of_test_cases | Exception desc: ", e)


# save_work_book() - To save the work book / excel whenever
# write_cell_data() functionality is called
def save_work_book(open_sheet):
    open_sheet.save(Constant.excel_test_data)


# test_run() - To retrieve number of line of test data for a particular test case to be considered
def test_row(sheet_name, test_case_name):
    row_list = []
    run_book = xlrd.open_workbook(Constant.excel_test_data)
    run_sheet = run_book.sheet_by_name(sheet_name)
    for rowId in range(run_sheet.nrows):
        row = run_sheet.row(rowId)
        for colID, cell in enumerate(row):
            if cell.value == test_case_name:
                row_list.append(rowId)
    return row_list


# retrieve_key_value() - To retrieve the response body dictionary key and value
# and write the key and value into cell values of excel sheet
def retrieve_key_value(b, tc_rows):
    try:
        j = 0
        for b_id, b_value in b.items():
            length = len(b[b_id])
            for i in range(0, length):
                for li_di, li_value in b[b_id][i].items():
                    print("Key :", li_di, "% Value:", li_value)
                    index = tc_rows[j]
                    write_cell_data(1, index, Constant.test_data_actBodyKey, li_di)
                    write_cell_data(1, index, Constant.test_data_actBodyValue, li_value)
                    j += 1
    except Exception as e:
        k = 0
        for key, value in b.items():
            print("Key:", key, "& value:", value)
            index = tc_rows[k]
            write_cell_data(1, index, Constant.test_data_actBodyKey, key)
            write_cell_data(1, index, Constant.test_data_actBodyValue, value)
            k += 1


# verify_before_pass_or_fail() - Finally logic to automatically validate the expected
# and actual result and publish the outcome
def verify_before_pass_or_fail(tc_row):
    for i in range(0, len(tc_row)):
        exp1 = read_cell_data(Constant.xcl_sheet_op, tc_row[i], Constant.test_data_expResponse)
        print(type(exp1))
        exp2 = read_cell_data(Constant.xcl_sheet_op, tc_row[i], Constant.test_data_expBodyKey)
        exp3 = read_cell_data(Constant.xcl_sheet_op, tc_row[i], Constant.test_data_expBodyValue)

        act1 = read_cell_data(Constant.xcl_sheet_op, tc_row[i], Constant.test_data_actResponse)
        # print(type(act1))
        act2 = read_cell_data(Constant.xcl_sheet_op, tc_row[i], Constant.test_data_actBodyKey)
        act3 = read_cell_data(Constant.xcl_sheet_op, tc_row[i], Constant.test_data_actBodyValue)

        if exp1 == act1:
            if exp2 == act2:
                if exp3 == act3:
                    write_cell_data(Constant.xcl_sheet_op, tc_row[i], Constant.test_data_result, Constant.test_case_pass)
                else:
                    write_cell_data(Constant.xcl_sheet_op, tc_row[i], Constant.test_data_result, "Fail - Mismatch Output")
            else:
                write_cell_data(Constant.xcl_sheet_op, tc_row[i], Constant.test_data_result, "Fail2")
        else:
            print(exp1, "is not ", act1)
            write_cell_data(Constant.xcl_sheet_op, tc_row[i], Constant.test_data_result, "Fail1")


def colour_cel(excel_sheet_name,):
    work_book_read = xlrd.open_workbook(Constant.excel_test_data)
    work_sheet = work_book_read.sheet_by_name(excel_sheet_name)

