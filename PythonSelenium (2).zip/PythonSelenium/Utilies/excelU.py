from xlrd import open_workbook

row_list = []
book = open_workbook('test_data_xl.xls')
# for sheet in book.sheets():
sheet = book.sheet_by_index(1)
for rowId in range(sheet.nrows):
    row = sheet.row(rowId)
    for colId, cell in enumerate(row):
        if cell.value == 'TC002':
            # print(sheet.name)
            # print(colId)
            row_list.append(rowId)
print(row_list)
