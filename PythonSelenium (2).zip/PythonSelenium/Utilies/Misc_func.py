@classmethod
def get_class_name(str_class_name):
    return str_class_name.__name__

