import pytest

def test_foo():
    with pytest.all