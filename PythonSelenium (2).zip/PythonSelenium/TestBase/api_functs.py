import requests
from deepdiff import DeepDiff
from Utilies import excel_utilies, Constant


class api_functs:
    @staticmethod
    def request_post(url, data, headers):
        global post
        try:
            post = requests.post(url, data=data, headers=headers)
        except Exception as e:
            print("api_functs | Method request_post | Exception desc: ", e)

    @staticmethod
    def get_status_code():
        return post.status_code

    @staticmethod
    def get_sentiment():
        sentiment = post.json()
        print(sentiment)
        return sentiment.get('sentiment')

    @staticmethod
    def get_score():
        score = post.json()
        print(score)
        return score.get('score')

    @staticmethod
    def get_json_value():
        return post.json()

    @staticmethod
    def deep_diff(dic1, dic2, tc_row):
        diff = DeepDiff(dic1, dic2)
        excel_utilies.write_cell_data(1, tc_row[0], Constant.test_data_actBodyKey, str(diff))
