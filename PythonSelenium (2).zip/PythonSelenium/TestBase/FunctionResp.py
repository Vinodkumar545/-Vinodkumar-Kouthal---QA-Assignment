from selenium import webdriver
from Utilies import Constant
from ObjResp import Objproperties
import time
import unittest


class FunctionResp(unittest.TestCase):
    @staticmethod
    def selectBrowser():
        try:
            global driver
            if Constant.select_Browser == 'chrome':
                driver = webdriver.Chrome(Constant.chrome_exe_path)
                print("Chrome browser successfully initialized!")
            elif Constant.select_Browser == 'firefox':
                driver = webdriver.Firefox()
            elif Constant.select_Browser == 'IE':
                driver = webdriver.Ie(Constant.ie_exe_path)
            else:
                print("Please...choose correct browser for testing!")
        except Exception as e:
            print("Class FunctionResp | Exception Desc: ", e)

    @staticmethod
    def getURL():
        try:
            driver.get(Constant.app_URL)
        except Exception as e:
            print("Class FunctionResp | Exception Desc: ", e)

    @staticmethod
    def maximizeWindows():
        try:
            driver.maximize_window()
        except Exception as e:
            print("Class FunctionResp | maximunWindows | Exception Desc: ", e)

    @staticmethod
    def implicitWait(seconds):
        try:
            driver.implicitly_wait(seconds)
        except Exception as e:
            print("Class FunctinResp | implicitWait | Exception Desc: ", e)

    @staticmethod
    def clearCookies():
        try:
            driver.delete_all_cookies()
        except Exception as e:
            print("Class FunctionResp | clearCookies | Exception Desc: ", e)

    @staticmethod
    def closeBrowser():
        try:
            driver.close()
        except Exception as e:
            print("Class FunctionResp | CloseBrowser | Exception desc: ", e)

    @staticmethod
    def sendKeys(str_element, str_value):
        try:
            send_element = Objproperties.locator(str_element, driver)
            send_element.send_keys(str_value)
        except Exception as e:
            print("Class FunctionResp | sendKeys } Exception desc: ", e)

    @staticmethod
    def click(str_element):
        try:
            click_element = Objproperties.locator(str_element, driver)
            click_element.click()
        except Exception as e:
            print("Class FunctionResP | click | Exception desc: ", e)

    @staticmethod
    def threadSleep(sleep_sec):
        try:
            time.sleep(sleep_sec)
        except Exception as e:
            print("Class FunctionResp | threadSleep | Exception Desc: ", e)