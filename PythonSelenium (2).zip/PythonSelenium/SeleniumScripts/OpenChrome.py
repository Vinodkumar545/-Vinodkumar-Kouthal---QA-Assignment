from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome("C:\\Users\\Rajshekhar\\Desktop\\Python access\\chromedriver.exe")

# driver.get("https://www.google.com")
driver.get("http://adjiva.com/qa-test/")
driver.maximize_window()
driver.implicitly_wait(20)

driver.find_element_by_name("first_name").send_keys("Vinodkumar")
# driver.find_element_by_name("last_name").send_keys("Kouthal")
driver.find_element_by_css_selector("input[name='last_name']").send_keys("Kouthal")

WebElement = driver.find_element_by_name("first_name")
WebElement.clear()

value = "first_name"
element = driver.find_element(By.NAME, value)
element.send_keys("Vinodkumar")

# driver.find_element_by_id()
# driver.find_element_by_xpath()
# driver.find_element_by_link_text()
# driver.find_element_by_partial_link_text()
# driver.find_element_by_name()
# driver.find_element_by_tag_name()
# driver.find_element_by_class_name()
# driver.find_element_by_css_selector()
# driver.find_element_by_name().click()