from TestBase import FunctionResp
from Utilies import excel_utilies, Constant


class FirstTest:
    # print("Second module name: {}".format(__name__))
    if __name__ == "__main__":
        for repeat in range(1, excel_utilies.get_number_of_test_cases()):
            print("vaue of repeast: ", repeat)
            print("runmode: ", excel_utilies.read_cell_data(Constant.excel_test_sheet_name, repeat, Constant.test_scenario_runmode))
            runMode_value = excel_utilies.read_cell_data(Constant.excel_test_sheet_name, repeat, Constant.test_scenario_runmode)
            if(runMode_value == "Yes"):
                excel_utilies.write_cell_data(repeat, Constant.test_scenario_resut, 'Pass')
                print("yes: ", excel_utilies.read_cell_data(Constant.excel_test_sheet_name, repeat,
                                             Constant.test_scenario_runmode))
            else:
                excel_utilies.write_cell_data(repeat, Constant.test_scenario_resut, 'Fail')
                print("NO: ", excel_utilies.read_cell_data(Constant.excel_test_sheet_name, repeat,
                                                            Constant.test_scenario_runmode))


        # FunctionResp.FunctionResp.selectBrowser()
        # FunctionResp.FunctionResp.getURL()
        # FunctionResp.FunctionResp.sendKeys("txtbx_firstname", "Vinodkumar")
        # FunctionResp.FunctionResp.sendKeys("txtbx_lastname", "Kouthal")
