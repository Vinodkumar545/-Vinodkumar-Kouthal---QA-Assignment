from TestBase import api_functs
from Utilies import Constant, excel_utilies
import json


class APIThridRun:
    if __name__ == '__main__':
        body = {}
        header = {}
        tc_rows = []
        for iterate in range(1, excel_utilies.get_no_of_iteration(Constant.excel_test_sheet_name, Constant.test_data_testID)):
            runMode_value = excel_utilies.read_cell_data(Constant.excel_test_sheet_name, iterate,
                                                         Constant.test_scenario_runmode)
            if runMode_value == "Yes":
                test_caseID1 = excel_utilies.read_cell_data(Constant.excel_test_sheet_name, iterate,
                                                           Constant.test_scenario_testID)
                tc_rows = excel_utilies.test_row(Constant.xcl_sheet_op, test_caseID1)
                if len(tc_rows) != 0:
                    url = excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[0], Constant.test_data_URL)
                    for body_iter in range(0, len(tc_rows)):
                        body_key = excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[body_iter],
                                                                    Constant.test_data_bodyKey)
                        body_Value = excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[body_iter],
                                                                          Constant.test_data_bodyValue)
                        if body_Value == 'False':
                            body[body_key] = False
                        elif body_Value == 'True':
                            body[body_key] = True
                        elif body_Value == '':
                            continue
                        else:
                            body[body_key] = body_Value

                    for header_iter in range(0, len(tc_rows)):
                        header_key = excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[header_iter],
                                                                  Constant.test_data_headerKey)
                        header_value = excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[header_iter],
                                                                          Constant.test_data_headerValue)
                        if header_value != '':
                            header[header_key] = header_value
                        else:
                            continue

                    pyToJs = json.dumps(body)

                    api_functs.api_functs.request_post(url, pyToJs, header)

                    excel_utilies.write_cell_data(1, tc_rows[0], Constant.test_data_actResponse,
                                                  str(api_functs.api_functs.get_status_code()))

                    excel_utilies.retrieve_key_value(api_functs.api_functs.get_json_value(), tc_rows)

                    excel_utilies.verify_before_pass_or_fail(tc_rows)
                else:
                    print("No test case on test-data sheet")
            else:
                excel_utilies.write_cell_data(0, iterate, Constant.test_scenario_result, Constant.test_case_fail)
