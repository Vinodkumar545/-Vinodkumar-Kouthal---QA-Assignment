from TestBase import api_functs
from Utilies import excel_utilies, Constant
import json


class API_First_Run:
    if __name__ == "__main__":
        body = {}
        header = {}
        testcaseID1 = excel_utilies.read_cell_data(Constant.excel_test_sheet_name, 1, 1)
        testcaseID2 = excel_utilies.read_cell_data(Constant.xcl_sheet_op, 2, 0)
        if(testcaseID1 == testcaseID2):
            url = excel_utilies.read_cell_data(Constant.xcl_sheet_op, 2, 1)

            body_newKey = excel_utilies.read_cell_data(Constant.xcl_sheet_op, 2, 2)
            body[body_newKey] = excel_utilies.read_cell_data(Constant.xcl_sheet_op, 2, 3)

            body['parse_html'] = False
            body['social_media'] = False

            header_newKey = excel_utilies.read_cell_data(Constant.xcl_sheet_op, 2, 4)
            header[header_newKey] = excel_utilies.read_cell_data(Constant.xcl_sheet_op, 2, 5)

            header['Authorization'] = excel_utilies.read_cell_data(Constant.xcl_sheet_op, 3, 5)

            print(body)
            print(header)
            pyToJs = json.dumps(body)
            print(pyToJs)

            api_functs.api_functs.request_post(url, pyToJs, header)
            excel_utilies.write_cell_data(1, 2, 9, str(api_functs.api_functs.get_status_code()))
            # api_functs.api_functs.get_sentiment()
            # api_functs.api_functs.get_score()
            excel_utilies.write_cell_data(1, 2, 10, str(api_functs.api_functs.get_sentiment()))
            excel_utilies.write_cell_data(1, 2, 11, str(api_functs.api_functs.get_score()))
