from TestBase import api_functs
from Utilies import Constant, excel_utilies
import json


class APISecondRun:
    if __name__ == '__main__':
        body = {}
        header = {}
        tc_rows = []
        for iterate in range(1, excel_utilies.get_number_of_test_cases()):
            runMode_value = excel_utilies.read_cell_data(Constant.excel_test_sheet_name, iterate, Constant.test_scenario_runmode)
            if (runMode_value == "Yes"):
                testcaseID1 = excel_utilies.read_cell_data(Constant.excel_test_sheet_name, iterate, Constant.test_scenario_testID)
                tc_rows = excel_utilies.test_run(Constant.xcl_sheet_op, testcaseID1)
                if(len(tc_rows) != 0):
                    url = excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[0], Constant.test_data_URL)

                    body_newKey1 = excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[0], Constant.test_data_bodyKey)
                    body[body_newKey1] = excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[0], Constant.test_data_bodyValue)

                    # body_newKey2 = excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[1], Constant.test_data_bodyKey)
                    # body[body_newKey2] = excel_utilies.get_boolean(excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[1], Constant.test_data_bodyValue))
                    #
                    # body_newKey3 = excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[2],
                    #                                             Constant.test_data_bodyKey)
                    # body[body_newKey3] = excel_utilies.get_boolean(
                    #     excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[2], Constant.test_data_bodyValue))

                    body['parse_html'] = False
                    body['social_media'] = False

                    # print(body)

                    header_newKey1 = excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[0], Constant.test_data_headerKey)
                    header[header_newKey1] = excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[0], Constant.test_data_headerValue)

                    header_newKey2 = excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[1], Constant.test_data_headerKey)
                    header[header_newKey2] = excel_utilies.read_cell_data(Constant.xcl_sheet_op, tc_rows[1], Constant.test_data_headerValue)
                    # print(header)

                    pyToJs = json.dumps(body)
                    # print(pyToJs)

                    api_functs.api_functs.request_post(url, pyToJs, header)

                    excel_utilies.write_cell_data(1, tc_rows[0], Constant.test_data_actResponse, str(api_functs.api_functs.get_status_code()))
                    # print(tc_rows)
                    # b = api_functs.api_functs.get_json_value()
                    # print(b)
                    # print(len(b))
                    excel_utilies.retrieve_key_value(api_functs.api_functs.get_json_value(), tc_rows)

                    excel_utilies.write_cell_data(0, iterate, Constant.test_scenario_result, Constant.test_case_pass)
                else:
                    print("No test case on test-data sheet")
            else:
                excel_utilies.write_cell_data(0, iterate, Constant.test_scenario_result, Constant.test_case_fail)
