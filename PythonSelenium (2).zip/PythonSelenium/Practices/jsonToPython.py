import json


dic = {}
# dct = {"text": "vinod", "is_open": True}
dic['text'] = 'Vinod'
dic['is_open'] = True
print(dic)
print(json.dumps(dic))
