# b = {
#   "sentiment": "VP",
#   "score": 5.07
# }

b = {
  "summarized_text": "And without resorting to the zombies-leaping-out-of-shadows approach of Doom III, it's all incredibly unsettling. Whereas the highly impressive Doom III felt like a top-notch theme park thrill-ride, wandering through Half-Life's world truly does feel like being part of a movie. Installing it proved a life-draining siege that would test a saint's patience. Human foes are rendered just as well as alien ones. The player sees things through the eyes of Gordon Freeman, the bespectacled scientist who starred in the original 1998 Half-Life. But if ever there was an incentive to upgrade your PC's components, this is it. In gameplay terms, HL2 somehow gets almost everything perfect. Exposition is accomplished by other characters stopping to talk directly to you. The bar has been raised, and so far out of sight that you have to sympathise with any game that tries to do anything remotely similar in the near future. Underplaying the narrative in this way is gloriously effective, and immerses the player in the most vivid, convincing and impressive virtual world they are likely to have seen. "
}

print(b.items())
try:
    for b_id, b_value in b.items():
        # print("\nKey Value: ", b_id)
        # print("no of list: ", len(b[b_id]))
        length = len(b[b_id])
        for i in range(0, length):
            # print(b[b_id][i].items())
            for li_di, li_value in b[b_id][i].items():
                print("\nKey : ", li_di, "% Value: ", li_value)
except Exception as e:
    for key, value in b.items():
        print("\nKey: ", key, "& value: ", value)
