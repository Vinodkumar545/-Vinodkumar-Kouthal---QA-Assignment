b = {
    'text' : 'Vinod',
    'lastname' : 'Kouthal'
}

row = [2, 3, 4]
for key, value in b.items():
    print("Key:", key, "& value:", value)
    j = 0
    index = row[j]
    print("Before value:", j)
    j+=1
    print("after value: ", j)
