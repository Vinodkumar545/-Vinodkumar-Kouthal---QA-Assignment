class get_class_name:
    pass


class_name = get_class_name()
str(class_name.__class__)
# print("Python class name: ", str(class_name.__class__))

print("Python class name: ", type(class_name).__name__)
