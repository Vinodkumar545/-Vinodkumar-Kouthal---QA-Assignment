from xlutils.copy import copy
import xlrd


def set_excel_file():
    rb = xlrd.open_workbook('sample.xls')
    return rb


def excel_write(wbb, row_num, col_num, str_input):
    # rb = xlrd.open_workbook('sample.xls')
    wb = copy(wbb)

    w_sheet = wb.get_sheet(0)

    w_sheet.write(row_num, col_num, str_input)
    w_sheet.write(row_num, col_num, str_input)
    w_sheet.write(row_num, col_num, str_input)
    w_sheet.write(row_num, col_num, str_input)

    wb.save('sample.xls')


def excel_read(wbb, row_num, col_num):
    # sh = wbb.get_sheet(0)
    print("value: ", sh.cell_value(row_num, col_num).value)


if __name__ == '__main__':
    rtwb = set_excel_file()
    excel_write(rtwb, 1, 2, 'rewrite_Awesome2')
    excel_write(rtwb, 2, 2, 'rewrite_Awesome2')
    excel_write(rtwb, 1, 1, 'rewrite_Awesome2')

    excel_read(rtwb, 1, 2)
    excel_read(rtwb, 2, 2,)
    excel_read(rtwb, 1, 1)
