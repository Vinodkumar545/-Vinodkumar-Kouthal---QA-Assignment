
if __name__ == '__main__':
    di = {
            "text": "Stride API works very well.",
            "parse_html": False,
            "social_media": False
        }

    new_dic = {}

    bool = True
    dic_length = len(di)
    # print(di.get('1'))
    # print()
    # for leng, key, values in di.items():
    #     print(len)
    #     new_dic[key] = values
    #     print(new_dic.pop(leng))
    #     # print(key, 'corresponds to ', values)

    # for i in range(1, dic_length+1):
    #     # print(isinstance(i, int))
    #     key_value = di.keys(i)
    #     print(key_value)

    for key in di:
        print("{} = {}".format(key, di[key]))
