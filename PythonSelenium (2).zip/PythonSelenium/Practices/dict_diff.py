from deepdiff import DeepDiff
from pprint import pprint


# Using deepdiff
dic1 = {
  "sentiment": "VP",
  "score": 5.07
}

dic2 = {'sentiment': 'VP', 'score': 8.0}
pprint(DeepDiff(dic1, dic2), indent=2)

# Output:
# {'values_changed': {"root['score']": {'new_value': 8.0, 'old_value': 5.07}}}

pprint(DeepDiff(dic1, dic2))
# Output
# {'values_changed': {"root['score']": {'new_value': 8.0, 'old_value': 5.07}}}

dict3 = {
  "sentiment_map": [
    {
      "category": "positive",
      "text": "food",
      "positive_score": 4.8,
      "negative_score": 0
    },
    {
      "category": "negative",
      "text": "service",
      "positive_score": 0,
      "negative_score": -7.2
    }
  ]
}

dic4 = {
    "sentiment_map": [
        {"category": "positive",
         "text": "food",
         "positive_score": 9.6,
         "negative_score": 0
         },
        {"category": "negative",
         "text": "service",
         "positive_score": 0,
         "negative_score": -8.4
         }
    ]
}
pprint(DeepDiff(dict3, dic4))

# Output
# {'values_changed': {"root['sentiment_map'][0]['positive_score']": {'new_value': 9.6,
#                                                                    'old_value': 4.8},
#                     "root['sentiment_map'][1]['negative_score']": {'new_value': -8.4,
#                                                                    'old_value': -7.2}}}
