import xlwt

# creating the workbook
wb = xlwt.Workbook(encoding="uft-8")

# adding sheets of the workbook
ws1 = wb.add_sheet('sheet 1', cell_overwrite_ok=True)
ws2 = wb.add_sheet('sheet 2', cell_overwrite_ok=True)
ws3 = wb.add_sheet('sheet 3', cell_overwrite_ok=True)

# Adding data to the workbook sheet
ws1.row(0).write(0, 'Data written in the first cell of first sheet')

ws1.write(0, 0, 'Data overwritten in the first cell of first sheet')

ws2.write(0, 0, 'Data written in the first cell of second sheet')

ws3.write(0, 0, 'Data written in the first cell of third sheet')

ws1.write(0, 1, 'Data written in the first row, second column of the first sheet')

ws1.row(1).write(1, 'Data written in the second row, second column of the first sheet')

var = "Data from variable written in the third row, second column of first sheet"
ws1.write(2, 1, var)

# To save the excel file
wb.save("C:\\Users\\Rajshekhar\\Desktop\\firstexcelwrite.xls")
