b = {
  "sentiment_map": [
    {
      "category": "positive",
      "text": "food",
      "positive_score": 4.8,
      "negative_score": 0
    }, {
      "category": "negative",
      "text": "service",
      "positive_score": 0,
      "negative_score": -7.2
    }, {
      "text": "Freuds experimentation had its hazards, too.",
      "score": 0,
      "sentiment": "N"
    }, {
      "text": "One associate, Ernst von Fleischl-Marxzow, had been dealing with a hand injury with large doses of morphine.",
      "score": -5,
      "sentiment": "VNe"
    }, {
      "text": "Dr. Freud administrated cocaine as a solution for the mans morphine addiction turned him into an addled, morphine-cocaine addict who died seven years later.",
      "score": -3.87,
      "sentiment": "Ne"
    }, {
      "text": "He was the first person known to suffer the paranoia and delusions of bugs crawling under the skin that are common to heavy cocaine addicts.",
      "score": -4.5,
      "sentiment": "Ne"
    }
  ]
}

print(b.items())
for b_id, b_value in b.items():
    # print("\nKey Value: ", b_id)
    # print("no of list: ", len(b[b_id]))
    # length = len(b[b_id])
    for i in range(0, len(b[b_id])):
        # print(b[b_id][i].items())
        # print("value of i: ", i)
        print("length; ", len(b[b_id][i]))
        for li_di, li_value in b[b_id][i].items():
            print("h")
            # print("\nKey : ", li_di, " & Value: ", li_value)

