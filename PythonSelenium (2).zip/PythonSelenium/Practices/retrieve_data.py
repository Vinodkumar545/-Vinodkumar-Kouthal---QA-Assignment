b = {
    "sentiment_map1":[
        {"category": "positive",
         "text": "food",
         "positive_score": 9.6,
         "negative_score": 0
         },                    
        {"category": "negative",
         "text": "service",
         "positive_score": 0,
         "negative_score": -8.4
         }
    ], "sentiment_map2": [
        {"category": "positive",
         "text": "food",
         "positive_score": 9.6,
         "negative_score": 0
         },
        {"category": "negative",
         "text": "service",
         "positive_score": 0,
         "negative_score": -8.4
         }
    ]
}


for b_id, b_info in b.items():
    print("\nKey Value: ", b_id)
    for i in range(0, len(b)):
        for li_key, li_value in b[b_id][i].items():
            print(li_key+":", li_value)

# for b_key, b_value in b.items():
#     print("\nKey Value: ", b_key)
#
#     for entry in b[b_key]:
#         print(entry)
#
#         for li_key, li_value in entry.items():
#             print(li_key + ':', li_value)

# for entry in b['sentiment_map1']:
#     print(entry)

# print(len(b))
# print(b.keys())
# print(b.items())

# print(b['sentiment_map'][0].keys())
# print(b['sentiment_map'][0].values())