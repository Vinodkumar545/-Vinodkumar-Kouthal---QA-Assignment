exp1 = 200
exp2 = 'positive_score'
exp3 = 4.8

act1 = 200
act2 = 'positive_score'
act3 = 9.6

if __name__ == '__main__':
    if exp1 == act1:
        if exp2 == act2:
            if exp3 == act3:
                print('All matching')
            else:
                print("VP is not matching")
        else:
            print("Sentiment is not matching!")
    else:
        print("Response not matching!")

