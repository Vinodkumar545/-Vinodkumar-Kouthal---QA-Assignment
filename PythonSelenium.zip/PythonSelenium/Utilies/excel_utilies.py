import xlrd, xlwt
import openpyxl


def set_excel_file(excel_path):
    global work_book
    try:
        work_book = xlrd.open_workbook(excel_path)
        # work_sheet = work_book.sheet_by_name(excel_sheet_name)
    except Exception as e:
        print("Class Excel_utilies | Method setexcelfile | Exception desc: ",e)


def read_cell_data(excel_sheet_name, row_num, col_num):
    try:
        work_sheet = work_book.sheet_by_name(excel_sheet_name)
        cell_value = work_sheet.cell(row_num, col_num).value
        return cell_value
    except Exception as e:
        print("Class Excel_utilies | Method get_Cell_Data | Exception desc: ",e)

def write_cell_data(excel_sheet_name, row_num, col_num, str_imput):
    try:
        work_book_write = openpyxl.load_workbook("C:\\Users\\Rajshekhar\\Desktop\\excel_read.xlsx")
        work_book_write_sheet = work_book_write.active
