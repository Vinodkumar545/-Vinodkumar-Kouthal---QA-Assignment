import xlrd, xlwt, openpyxl


w2 = xlrd.open_workbook("C:\\Users\\Rajshekhar\\Desktop\\excel_read.xlsx")
sh = w2.sheet_by_index(0)

print("Number of rows in sh1: ", int(sh.nrows))
print("List of cell values in 1st row: ", sh.row_values(0))
print("Number of columns in sh1: ", int(sh.ncols))
print("List of cell values in 2nd column: ", sh.col_values(1))
print("Data in 1st cell of sheet1: ", sh.cell(0, 0).value)
print("Data in 3rd row, 2nd col of shee1: ", sh.cell(2, 1).value)

# print(int(sh.cell(0, 0).value))

mywb = openpyxl.load_workbook("C:\\Users\\Rajshekhar\\Desktop\\excel_read.xlsx")
# print(mywb.get_sheet_names())
# wr_sh = mywb.get_sheet_names().index(1)

# wr_sh.write(9, 9, "written text")

wr_sh = mywb.active
wr_sh.write(9, 9, "written text")


# print(mysheet.title)
