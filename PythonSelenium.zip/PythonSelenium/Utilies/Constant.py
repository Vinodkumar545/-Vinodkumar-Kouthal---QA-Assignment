select_Browser = "chrome"
app_URL = "http://adjiva.com/qa-test/"

# folder Paths
chrome_exe_path = "C:\\Users\\Rajshekhar\\Desktop\\Python access\\chromedriver.exe"
ie_exe_path = "C:\\Users\\Rajshekhar\\Desktop\\Python access\\IEDriverServer.exe"
objec_resp_properies = "C:\\Users\\Rajshekhar\\PycharmProjects\\PythonSelenium\\ObjResp\\objectResp.properties"