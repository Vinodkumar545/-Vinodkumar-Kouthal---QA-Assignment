from TestBase import FunctionResp

print("Second module name: {}".format(__name__))

if __name__ == "__main__":
    FunctionResp.FunctionResp.selectBrowser()
    FunctionResp.FunctionResp.getURL()
    FunctionResp.FunctionResp.sendKeys("txtbx_firstname", "Vinodkumar")
    FunctionResp.FunctionResp.sendKeys("txtbx_lastname", "Kouthal")
