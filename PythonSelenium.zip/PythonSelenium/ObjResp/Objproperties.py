from Utilies import Constant


def locator(obj_value, driver):
    file_name = Constant.objec_resp_properies
    file_obj = open(file_name, 'r')
    my_dist = {}
    for line in file_obj:
        line = line.strip()
        key_value = line.split("==")
        if len(key_value) == 2:
            my_dist[key_value[0]] = key_value[1]

    act_obj_value = str(my_dist.get(obj_value))
    webelement_locator = act_obj_value.split(":")
    locator_typename = str(webelement_locator[0])
    locator_value = str(webelement_locator[1])

    try:
        if (locator_typename == "id"):
            return driver.find_element_by_id(locator_value)
        elif (locator_typename == "xpath"):
            return driver.find_element_by_xpath(locator_value)
        elif (locator_typename == "linktext"):
            return driver.find_element_by_link_text(locator_value)
        elif (locator_typename == "partiallinktext"):
            return driver.find_element_by_partial_link_text(locator_value)
        elif (locator_typename == 'name'):
            return driver.find_element_by_name(locator_value)
        elif (locator_typename == "tagname"):
            return driver.find_element_by_tag_name(locator_value)
        elif (locator_typename == "claasname"):
            return driver.find_element_by_class_name(locator_value)
        elif (locator_typename == 'css'):
            return driver.find_element_by_css_selector(locator_value)
    except Exception as e:
        print("obj property Exception : ", e)
